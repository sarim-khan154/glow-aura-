---
name: Glow Aura
colors:
  surface: '#fff8f7'
  surface-dim: '#e7d6d6'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f0'
  surface-container: '#fbeae9'
  surface-container-high: '#f5e4e4'
  surface-container-highest: '#efdfde'
  on-surface: '#221a1a'
  on-surface-variant: '#524345'
  inverse-surface: '#382e2e'
  inverse-on-surface: '#feedec'
  outline: '#857374'
  outline-variant: '#d7c1c3'
  surface-tint: '#8c4b55'
  primary: '#8a4853'
  on-primary: '#ffffff'
  primary-container: '#a6606b'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2bc'
  secondary: '#755a23'
  on-secondary: '#ffffff'
  secondary-container: '#fdd894'
  on-secondary-container: '#785d25'
  tertiary: '#6f5652'
  on-tertiary: '#ffffff'
  tertiary-container: '#896f6a'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dd'
  primary-fixed-dim: '#ffb2bc'
  on-primary-fixed: '#3a0915'
  on-primary-fixed-variant: '#70343e'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e6c280'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5b430c'
  tertiary-fixed: '#fcdbd5'
  tertiary-fixed-dim: '#dfbfba'
  on-tertiary-fixed: '#291714'
  on-tertiary-fixed-variant: '#58413d'
  background: '#fff8f7'
  on-background: '#221a1a'
  surface-variant: '#efdfde'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '400'
    lineHeight: 38px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system embodies an editorial luxury beauty experience that balances regal sophistication with welcoming warmth. Rather than adopting an austere, sterile high-fashion stance, the aesthetic invites touch and ritual through creamy canvas tones, soft rose metallics, and gentle luminescent depths. 

The target audience comprises conscious luxury beauty and skincare enthusiasts who value craftsmanship, tactile formulation, and sensory self-care. The visual language conveys effortless radiance, intimate prestige, and calm assurance through expansive negative space, high-fashion editorial serif typography, and delicate gold-leaf highlights.

## Colors

The palette is founded on an organic cream ecosystem rather than stark digital white, providing an intimate, boudoir-inspired backdrop that makes product imagery glow.

- **Primary (`#B76E79` Rose Gold):** The signature touchpoint used for key actions, brand marks, and focused interactive states. Pair with its softer tint (`#C88A92`) for gentle hover and pressed feedback.
- **Secondary (`#E6C280` Champagne Gold):** Reserved for delicate metallic accents, premium badges, ratings, ribbons, and hairline highlights.
- **Tertiary (`#F7D6D0` Blush Silk):** Used for elevated cards, active indicator pills, and ambient atmospheric backgrounds alongside blush tint (`#FCEEE9`).
- **Neutral (`#2D2424` Deep Espresso & `#4A3E3D` Warm Umber):** High-contrast yet softer than pitch black, preventing harsh lines on pale backgrounds.
- **Surfaces & Borders:** Base surfaces use warm ivory (`#FDFBF7`) transitioning to `#FAF6F0` for containers. Structural lines utilize subtle blush-veined borders (`#EEDCD5`).

## Typography

The typography system pairs the high-contrast, editorial elegance of `Playfair Display` with the balanced, humanistic geometry of `Plus Jakarta Sans`.

- **Headlines & Titles:** Set with generous line height to honor editorial layout practices. Italic styles of `Playfair Display` should be leveraged sparingly on accent words (e.g., *Radiance*, *Elixir*) to add artisanal flair.
- **Body & Micro-Copy:** `Plus Jakarta Sans` provides frictionless legibility across ingredient lists, product descriptions, and transactional checkouts.
- **Labels & Overlines:** Up-cased micro-labels utilize wide letter-spacing (`0.06em` to `0.08em`) to mirror luxury perfumery and apothecary packaging conventions.

## Layout & Spacing

The layout philosophy mirrors the cadence of high-end editorial magazines, relying on open breathability, rhythm, and intentional asymmetry over dense data packing.

- **Grid Strategy:** A responsive 12-column grid on desktop (max container width 1320px) transitioning to a 6-column grid on tablet, and a 4-column fluid layout on mobile devices.
- **Margin Hierarchy:** Generous desktop canvas margins (`3rem`) preserve whitespace around hero images and product galleries, shrinking gracefully to `1.25rem` on mobile.
- **Component Spacing:** Spacing tokens govern element breathing room. High vertical padding (`space-xl`) between narrative sections creates distinct atmospheric pauses, while internal card padding relies strictly on `space-md` and `space-lg`.

## Elevation & Depth

Visual hierarchy uses subtle tonal transitions and multi-layered, petal-soft diffusion rather than stark drop shadows.

- **Tonal Layers:** Elevated containers emerge by shifting surface tonality from base `#FDFBF7` to `#FAF6F0`, bounded by ultra-fine `#EEDCD5` boundaries.
- **Subtle Glow Casts:** Floating cards and drawers cast an extra-diffused ambient shadow tinted with warm rose-charcoal: `0 12px 32px -4px rgba(45, 36, 36, 0.05), 0 4px 12px -2px rgba(183, 110, 121, 0.06)`.
- **Modals & Overlays:** Backdrops apply a smooth dual blur (`backdrop-filter: blur(12px)`) accompanied by an ethereal blush-tinted wash (`rgba(253, 251, 247, 0.72)`).

## Shapes

The shape system adopts a fluid, pill-inspired architecture to evoke organic beauty packaging, droplet fluidity, and smooth ceramic jars.

- **Pill Elements (`rounded-full` / Level 3):** Buttons, search pills, interactive chips, and floating notification badges adopt fully rounded pill profiles.
- **Containers & Modals:** Product display cards, dialogs, and slide-in panels utilize large radii (`1.5rem` to `2rem`) to soften structural framing.
- **Media Radii:** Hero imagery and swatch showcases mirror container roundedness or adopt soft arched motifs to echo classic architectural vanity mirrors.

## Components

- **Buttons:** 
  - *Primary:* Solid `#B76E79` background with white text, pill-shaped, standard height of 48px, subtle rose illumination on hover, scale down by 1% on active press.
  - *Secondary / Outline:* Translucent ivory background bordered with a 1px `#B76E79` stroke, text in `#2D2424`, transitioning to `#FCEEE9` fill on interaction.
  - *Text Action:* Understated, paired with a champagne gold (`#D4AF37`) hairline underline that expands outward on hover.

- **Chips & Filters:**
  - Designed as slim pills with 32px height. Unselected states display `#FAF6F0` surface with `#EEDCD5` borders; selected states fill with `#F7D6D0` bordered in `#B76E79` with a subtle deep warm brown text.

- **Input Fields:**
  - Pill-shaped or soft rounded-lg frames featuring `#FAF6F0` fills, 1px border in `#EEDCD5`, and rich espresso text (`#2D2424`). Placeholder text sits in muted brown (`#4A3E3D` at 50% opacity). Focus states emit an aura ring: `0 0 0 3px rgba(183, 110, 121, 0.2)` with a `#B76E79` border transition.

- **Checkboxes & Radios:**
  - Circular and droplet shapes. Radio selections showcase an inner dot colored with `#B76E79`; checkboxes feature a soft champagne gold accent checkmark within a rose-gold circular perimeter.

- **Cards:**
  - Product cards sport a borderless, warm `#FAF6F0` surface or a razor-thin 1px `#EEDCD5` outline. Hover states invoke a slight upward translation (-4px) alongside warm diffused shadow casting. Product thumbnails are enclosed in generous inner padding to spotlight packaging form.

- **Specialized Beauty Components:**
  - *Color Swatch Selector:* Concentric circular rings with an active 2px outer gap framing the chosen tone.
  - *Formula Rating / Badges:* Champagne gold (`#D4AF37`) stars accompanied by an uppercase `label-sm` counter.
  - *Ingredient Drawer:* Bottom sheet with frosted cream backdrop blur and pill grab handle.